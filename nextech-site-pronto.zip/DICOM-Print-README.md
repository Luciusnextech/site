# XPrint DICOM

Aplicativo desktop para receber trabalhos DICOM Print, importar imagens DICOM,
montar folhas, visualizar, exportar para PDF e imprimir.

## Executar

```powershell
python -m pip install -r requirements.txt
python xprint_dicom.py
```

Na primeira execução, abra **Configurações** e defina:

- AE Title (padrão: `XPRINT`)
- Porta DICOM (padrão: `11112`)
- Pasta de saída

Depois clique em **Iniciar servidor**. Configure a modalidade de origem com o
IP do computador, o AE Title e a porta escolhidos.

## Regras por AET

Abra **Rules Configuration**, adicione os AETs de origem permitidos e configure
o layout e os ajustes padrao de cada modalidade. Quando existir pelo menos uma
regra, associacoes de AETs que nao estejam ativos na lista serao recusadas.

## Edicao antes de imprimir

Selecione um trabalho e abra **Editor de Folha**. Nessa tela e possivel
adicionar, remover e ordenar imagens, escolher linhas e colunas, mudar o fundo
e ajustar gamma, contraste, saturacao e brilho antes de salvar ou imprimir.

## Funções

- DICOM Verification (`C-ECHO`)
- DICOM Print SCP para imagens grayscale e coloridas
- Recepção e composição de folhas por layout
- Histórico persistente em SQLite
- Importação de arquivos DICOM
- Pré-visualização, impressão, exportação PDF e exclusão
- Configurações persistentes
- Rules Configuration com autorização e ajustes por AET de origem
- Editor de folha para adicionar, remover e ordenar várias imagens
- Layout configurável em linhas e colunas antes da impressão
- Fundo preto ou branco
- Ajustes de gamma, contraste, saturação e brilho

> Este software é um projeto independente com identidade própria. Antes do uso
> clínico, faça validação de interoperabilidade, segurança e conformidade
> regulatória aplicável.
